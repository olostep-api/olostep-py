"""Transport protocol definition for the Olostep SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

__all__ = ["Transport", "RawAPIRequest", "RawAPIResponse", "close_transport"]


@dataclass
class RawAPIRequest:
    """Raw API request containing method, url, query, json, and headers."""
    method: str
    url: str
    query: dict[str, Any] | None = None
    json: dict[str, Any] | None = None
    headers: dict[str, str] | None = None

@dataclass
class RawAPIResponse:
    """Raw API response containing status code, headers, and response text."""
    status_code: int
    headers: dict[str, str]
    body: str


class Transport(Protocol):
    """Protocol defining the interface for HTTP transport implementations."""

    async def request(
        self,
        method_or_request: str | RawAPIRequest,
        url: str | None = None,
        *,
        json: dict[str, Any] | None = None,
        query: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> RawAPIResponse:
        """
        Make an HTTP request.

        Args:
            method_or_request: HTTP method (str) or RawAPIRequest object
            url: Request URL (required if method_or_request is str)
            json: JSON payload for request body
            query: Query parameters
            headers: Additional headers

        Returns:
            RawAPIResponse containing status_code, headers, and response_text
        """
        ...

    async def close(self) -> None:
        """
        Close any resources used by the transport.

        This method should be implemented by all transport implementations
        to ensure proper cleanup of connections, sessions, or other resources.
        """
        ...


async def close_transport(transport: Transport) -> None:
    """
    Utility function to properly close a transport instance.

    This function provides a safe way to close transport resources
    for users who manage their own transport lifecycle.

    Args:
        transport: The transport instance to close

    Example:
        >>> transport = HttpxTransport("api_key")
        >>> await close_transport(transport)
    """
    await transport.close()
